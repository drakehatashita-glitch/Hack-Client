package com.shieldmacemod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public class ShieldMaceMod implements ClientModInitializer {

    public static class_304 openGuiKey;
    public static class_304 toggleComboKey;
    public static class_304 toggleBreachSwapKey;
    public static class_304 toggleMaceSpamKey;
    public static class_304 togglePearlInterceptKey;
    public static class_304 toggleSilentAimKey;
    public static class_304 toggleHeightSmashKey;
    public static class_304 toggleHitboxExpandKey;
    public static class_304 toggleAutoTotemKey;
    public static class_304 toggleNoFallKey;
    public static class_304 toggleKillAuraKey;
    public static class_304 toggleFlightKey;
    public static class_304 toggleBlinkKey;

    // Movement
    public static class_304 toggleSpeedKey;
    public static class_304 toggleSprintKey;
    public static class_304 toggleStepKey;
    public static class_304 toggleLongJumpKey;
    public static class_304 toggleJesusKey;
    public static class_304 toggleSpiderKey;
    public static class_304 toggleGlideKey;

    // Combat
    public static class_304 toggleTriggerBotKey;
    public static class_304 toggleAutoClickerKey;
    public static class_304 toggleCriticalsKey;
    public static class_304 toggleReachKey;
    public static class_304 toggleAntiKnockbackKey;

    // Player Assist
    public static class_304 toggleAutoArmorKey;
    public static class_304 toggleFastUseKey;
    public static class_304 toggleInventoryMoveKey;
    public static class_304 toggleChestStealerKey;

    // Render
    public static class_304 toggleXrayKey;
    public static class_304 toggleEspKey;
    public static class_304 toggleTracersKey;
    public static class_304 toggleFullbrightKey;
    public static class_304 toggleNameTagsKey;

    public static ShieldMaceFeature feature;
    public static PearlInterceptor   pearlInterceptor;

    private static final int GLFW_KEY_UNKNOWN       = -1;
    private static final int GLFW_KEY_RIGHT_SHIFT   = 344;
    private static final int GLFW_KEY_RIGHT_CONTROL = 345;
    private static final int GLFW_KEY_RIGHT_ALT     = 346;

    private static class_304 kb(String id, int code) {
        return KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod." + id,
                class_3675.class_307.field_1668,
                code,
                class_304.class_11900.field_62556));
    }

    @Override
    public void onInitializeClient() {
        openGuiKey              = kb("openGui",              GLFW_KEY_RIGHT_SHIFT);
        toggleComboKey          = kb("toggleCombo",          GLFW_KEY_UNKNOWN);
        toggleBreachSwapKey     = kb("toggleBreachSwap",     GLFW_KEY_RIGHT_CONTROL);
        toggleMaceSpamKey       = kb("toggleMaceSpam",       GLFW_KEY_RIGHT_ALT);
        togglePearlInterceptKey = kb("togglePearlIntercept", GLFW_KEY_UNKNOWN);
        toggleSilentAimKey      = kb("toggleSilentAim",      GLFW_KEY_UNKNOWN);
        toggleHeightSmashKey    = kb("toggleHeightSmash",    GLFW_KEY_UNKNOWN);
        toggleHitboxExpandKey   = kb("toggleHitboxExpand",   GLFW_KEY_UNKNOWN);
        toggleAutoTotemKey      = kb("toggleAutoTotem",      GLFW_KEY_UNKNOWN);
        toggleNoFallKey         = kb("toggleNoFall",         GLFW_KEY_UNKNOWN);
        toggleKillAuraKey       = kb("toggleKillAura",       GLFW_KEY_UNKNOWN);
        toggleFlightKey         = kb("toggleFlight",         GLFW_KEY_UNKNOWN);
        toggleBlinkKey          = kb("toggleBlink",          GLFW_KEY_UNKNOWN);

        toggleSpeedKey          = kb("toggleSpeed",          GLFW_KEY_UNKNOWN);
        toggleSprintKey         = kb("toggleSprint",         GLFW_KEY_UNKNOWN);
        toggleStepKey           = kb("toggleStep",           GLFW_KEY_UNKNOWN);
        toggleLongJumpKey       = kb("toggleLongJump",       GLFW_KEY_UNKNOWN);
        toggleJesusKey          = kb("toggleJesus",          GLFW_KEY_UNKNOWN);
        toggleSpiderKey         = kb("toggleSpider",         GLFW_KEY_UNKNOWN);
        toggleGlideKey          = kb("toggleGlide",          GLFW_KEY_UNKNOWN);

        toggleTriggerBotKey     = kb("toggleTriggerBot",     GLFW_KEY_UNKNOWN);
        toggleAutoClickerKey    = kb("toggleAutoClicker",    GLFW_KEY_UNKNOWN);
        toggleCriticalsKey      = kb("toggleCriticals",      GLFW_KEY_UNKNOWN);
        toggleReachKey          = kb("toggleReach",          GLFW_KEY_UNKNOWN);
        toggleAntiKnockbackKey  = kb("toggleAntiKnockback",  GLFW_KEY_UNKNOWN);

        toggleAutoArmorKey      = kb("toggleAutoArmor",      GLFW_KEY_UNKNOWN);
        toggleFastUseKey        = kb("toggleFastUse",        GLFW_KEY_UNKNOWN);
        toggleInventoryMoveKey  = kb("toggleInventoryMove",  GLFW_KEY_UNKNOWN);
        toggleChestStealerKey   = kb("toggleChestStealer",   GLFW_KEY_UNKNOWN);

        toggleXrayKey           = kb("toggleXray",           GLFW_KEY_UNKNOWN);
        toggleEspKey            = kb("toggleEsp",            GLFW_KEY_UNKNOWN);
        toggleTracersKey        = kb("toggleTracers",        GLFW_KEY_UNKNOWN);
        toggleFullbrightKey     = kb("toggleFullbright",     GLFW_KEY_UNKNOWN);
        toggleNameTagsKey       = kb("toggleNameTags",       GLFW_KEY_UNKNOWN);

        feature          = new ShieldMaceFeature();
        pearlInterceptor = new PearlInterceptor();

        // Render hooks (ESP / Tracers / X-Ray ore highlight / Name Tags)
        RenderHooks.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.method_1436()) client.method_1507(new ShieldMaceGui());
            while (toggleComboKey.method_1436())          feature.toggleCombo(client);
            while (toggleBreachSwapKey.method_1436())     feature.toggleBreachSwap(client);
            while (toggleMaceSpamKey.method_1436())       feature.toggleMaceSpam(client);
            while (togglePearlInterceptKey.method_1436()) pearlInterceptor.toggle(client);
            while (toggleSilentAimKey.method_1436())      feature.toggleSilentAim(client);
            while (toggleHeightSmashKey.method_1436())    feature.toggleHeightSmash(client);
            while (toggleHitboxExpandKey.method_1436())   feature.toggleHitboxExpand(client);
            while (toggleAutoTotemKey.method_1436())      feature.toggleAutoTotem(client);
            while (toggleNoFallKey.method_1436())         feature.toggleNoFall(client);
            while (toggleKillAuraKey.method_1436())       feature.toggleKillAura(client);
            while (toggleFlightKey.method_1436())         feature.toggleFlight(client);
            while (toggleBlinkKey.method_1436())          feature.toggleBlink(client);

            while (toggleSpeedKey.method_1436())          feature.toggleSimple(client, "Speed",        () -> ShieldMaceSettings.INSTANCE.speedEnabled        = !ShieldMaceSettings.INSTANCE.speedEnabled,        () -> ShieldMaceSettings.INSTANCE.speedEnabled);
            while (toggleSprintKey.method_1436())         feature.toggleSimple(client, "Sprint",       () -> ShieldMaceSettings.INSTANCE.sprintEnabled       = !ShieldMaceSettings.INSTANCE.sprintEnabled,       () -> ShieldMaceSettings.INSTANCE.sprintEnabled);
            while (toggleStepKey.method_1436())           feature.toggleSimple(client, "Step",         () -> ShieldMaceSettings.INSTANCE.stepEnabled         = !ShieldMaceSettings.INSTANCE.stepEnabled,         () -> ShieldMaceSettings.INSTANCE.stepEnabled);
            while (toggleLongJumpKey.method_1436())       feature.toggleSimple(client, "Long Jump",    () -> ShieldMaceSettings.INSTANCE.longJumpEnabled     = !ShieldMaceSettings.INSTANCE.longJumpEnabled,     () -> ShieldMaceSettings.INSTANCE.longJumpEnabled);
            while (toggleJesusKey.method_1436())          feature.toggleSimple(client, "Jesus",        () -> ShieldMaceSettings.INSTANCE.jesusEnabled        = !ShieldMaceSettings.INSTANCE.jesusEnabled,        () -> ShieldMaceSettings.INSTANCE.jesusEnabled);
            while (toggleSpiderKey.method_1436())         feature.toggleSimple(client, "Spider",       () -> ShieldMaceSettings.INSTANCE.spiderEnabled       = !ShieldMaceSettings.INSTANCE.spiderEnabled,       () -> ShieldMaceSettings.INSTANCE.spiderEnabled);
            while (toggleGlideKey.method_1436())          feature.toggleSimple(client, "Glide",        () -> ShieldMaceSettings.INSTANCE.glideEnabled        = !ShieldMaceSettings.INSTANCE.glideEnabled,        () -> ShieldMaceSettings.INSTANCE.glideEnabled);

            while (toggleTriggerBotKey.method_1436())     feature.toggleSimple(client, "TriggerBot",   () -> ShieldMaceSettings.INSTANCE.triggerBotEnabled   = !ShieldMaceSettings.INSTANCE.triggerBotEnabled,   () -> ShieldMaceSettings.INSTANCE.triggerBotEnabled);
            while (toggleAutoClickerKey.method_1436())    feature.toggleSimple(client, "AutoClicker",  () -> ShieldMaceSettings.INSTANCE.autoClickerEnabled  = !ShieldMaceSettings.INSTANCE.autoClickerEnabled,  () -> ShieldMaceSettings.INSTANCE.autoClickerEnabled);
            while (toggleCriticalsKey.method_1436())      feature.toggleSimple(client, "Criticals",    () -> ShieldMaceSettings.INSTANCE.criticalsEnabled    = !ShieldMaceSettings.INSTANCE.criticalsEnabled,    () -> ShieldMaceSettings.INSTANCE.criticalsEnabled);
            while (toggleReachKey.method_1436())          feature.toggleSimple(client, "Reach",        () -> ShieldMaceSettings.INSTANCE.reachEnabled        = !ShieldMaceSettings.INSTANCE.reachEnabled,        () -> ShieldMaceSettings.INSTANCE.reachEnabled);
            while (toggleAntiKnockbackKey.method_1436())  feature.toggleSimple(client, "Anti-Knockback",() -> ShieldMaceSettings.INSTANCE.antiKnockbackEnabled = !ShieldMaceSettings.INSTANCE.antiKnockbackEnabled, () -> ShieldMaceSettings.INSTANCE.antiKnockbackEnabled);

            while (toggleAutoArmorKey.method_1436())      feature.toggleSimple(client, "AutoArmor",    () -> ShieldMaceSettings.INSTANCE.autoArmorEnabled    = !ShieldMaceSettings.INSTANCE.autoArmorEnabled,    () -> ShieldMaceSettings.INSTANCE.autoArmorEnabled);
            while (toggleFastUseKey.method_1436())        feature.toggleSimple(client, "FastUse",      () -> ShieldMaceSettings.INSTANCE.fastUseEnabled      = !ShieldMaceSettings.INSTANCE.fastUseEnabled,      () -> ShieldMaceSettings.INSTANCE.fastUseEnabled);
            while (toggleInventoryMoveKey.method_1436())  feature.toggleSimple(client, "InventoryMove",() -> ShieldMaceSettings.INSTANCE.inventoryMoveEnabled = !ShieldMaceSettings.INSTANCE.inventoryMoveEnabled, () -> ShieldMaceSettings.INSTANCE.inventoryMoveEnabled);
            while (toggleChestStealerKey.method_1436())   feature.toggleSimple(client, "ChestStealer", () -> ShieldMaceSettings.INSTANCE.chestStealerEnabled = !ShieldMaceSettings.INSTANCE.chestStealerEnabled, () -> ShieldMaceSettings.INSTANCE.chestStealerEnabled);

            while (toggleXrayKey.method_1436())           feature.toggleSimple(client, "X-Ray",        () -> ShieldMaceSettings.INSTANCE.xrayEnabled         = !ShieldMaceSettings.INSTANCE.xrayEnabled,         () -> ShieldMaceSettings.INSTANCE.xrayEnabled);
            while (toggleEspKey.method_1436())            feature.toggleSimple(client, "ESP",          () -> ShieldMaceSettings.INSTANCE.espEnabled          = !ShieldMaceSettings.INSTANCE.espEnabled,          () -> ShieldMaceSettings.INSTANCE.espEnabled);
            while (toggleTracersKey.method_1436())        feature.toggleSimple(client, "Tracers",      () -> ShieldMaceSettings.INSTANCE.tracersEnabled      = !ShieldMaceSettings.INSTANCE.tracersEnabled,      () -> ShieldMaceSettings.INSTANCE.tracersEnabled);
            while (toggleFullbrightKey.method_1436())     feature.toggleSimple(client, "Fullbright",   () -> ShieldMaceSettings.INSTANCE.fullbrightEnabled   = !ShieldMaceSettings.INSTANCE.fullbrightEnabled,   () -> ShieldMaceSettings.INSTANCE.fullbrightEnabled);
            while (toggleNameTagsKey.method_1436())       feature.toggleSimple(client, "NameTags",     () -> ShieldMaceSettings.INSTANCE.nameTagsEnabled     = !ShieldMaceSettings.INSTANCE.nameTagsEnabled,     () -> ShieldMaceSettings.INSTANCE.nameTagsEnabled);

            feature.tick(client);
            pearlInterceptor.tick(client);
        });
    }
}
