package com.shieldmacemod.mixin;

import com.shieldmacemod.ShieldMaceSettings;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * NoFall via outgoing-packet spoof.
 *
 * The vanilla server only deals fall damage when a position packet arrives
 * with onGround=true after the server has accumulated fall-distance. By
 * forcing this packet's onGround() accessor to return true whenever the
 * local player is currently falling more than ~2 blocks, the server's
 * fall-distance is reset every tick, so it never reaches the >3-block
 * threshold required to deal damage.
 *
 * The 2-block guard prevents the spoof from firing during normal walking
 * jumps (where fallDistance briefly spikes to ~1.25 on landing) so that
 * tiny jumps don't accidentally desync the server's onGround state.
 */
@Mixin(class_2828.class)
public abstract class PlayerMoveC2SPacketMixin {

    @Inject(method = "onGround", at = @At("HEAD"), cancellable = true)
    private void shieldmacemod$noFall(CallbackInfoReturnable<Boolean> cir) {
        ShieldMaceSettings settings = ShieldMaceSettings.INSTANCE;
        if (!settings.noFallEnabled) return;

        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;

        if (mc.field_1724.field_6017 >= 2.0f) {
            cir.setReturnValue(true);
        }
    }
}
