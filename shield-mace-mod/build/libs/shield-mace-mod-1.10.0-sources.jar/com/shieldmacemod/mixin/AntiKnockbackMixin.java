package com.shieldmacemod.mixin;

import com.shieldmacemod.ShieldMaceSettings;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Anti-Knockback — cancel server-sent velocity updates that target the
 * local player. The vanilla server pushes the player on hit by sending
 * an {@link class_2743} with the new velocity; we
 * silently drop those packets so the player isn't knocked back.
 *
 * Updates targeting other entities are passed through normally.
 */
@Mixin(class_634.class)
public abstract class AntiKnockbackMixin {

    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void shieldmacemod$antiKb(class_2743 packet, CallbackInfo ci) {
        if (!ShieldMaceSettings.INSTANCE.antiKnockbackEnabled) return;

        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;

        if (packet.method_11818() == mc.field_1724.method_5628()) {
            ci.cancel();
        }
    }
}
