package com.shieldmacemod.mixin;

import com.shieldmacemod.ShieldMaceSettings;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2828;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Criticals — fire a fake hop sequence right before every melee attack
 * so the server thinks the player is airborne and applies the vanilla
 * critical-hit multiplier. The hop is tiny (~0.0625 b) so it never
 * trips a movement-too-fast check, and the player's tracked position
 * is restored on the third packet so reach is preserved.
 *
 * Only fires when the player is on the ground; if they're already
 * falling vanilla criticals already apply.
 */
@Mixin(class_636.class)
public abstract class CriticalsMixin {

    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void shieldmacemod$criticals(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (!ShieldMaceSettings.INSTANCE.criticalsEnabled) return;
        if (!(player instanceof class_746 cp)) return;
        if (cp.field_3944 == null) return;
        if (!cp.method_24828()) return;
        if (cp.method_6101() || cp.method_5799() || cp.method_5771()) return;
        if (cp.method_5765()) return;

        double x = cp.method_23317(), y = cp.method_23318(), z = cp.method_23321();
        var net = cp.field_3944;
        net.method_52787(new class_2828.class_2829(x, y + 0.0625, z, false, false));
        net.method_52787(new class_2828.class_2829(x, y + 0.0001, z, false, false));
        net.method_52787(new class_2828.class_2829(x, y, z, false, false));
    }
}
