package com.shieldmacemod.mixin;

import com.shieldmacemod.ShieldMaceSettings;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * InventoryMove — when the player has a screen open (inventory, chest, …)
 * vanilla locks the movement keys to "not pressed". This mixin checks the
 * physical key state directly so movement / jumping / sneaking continue to
 * work while a non-chat screen is open.
 *
 * Only fires when InventoryMove is enabled and the open screen is not a
 * chat or sign edit screen (we don't want to walk while typing).
 */
@Mixin(class_304.class)
public abstract class KeyBindingMixin {

    @Inject(method = "isPressed", at = @At("HEAD"), cancellable = true)
    private void shieldmacemod$inventoryMove(CallbackInfoReturnable<Boolean> cir) {
        if (!ShieldMaceSettings.INSTANCE.inventoryMoveEnabled) return;

        class_310 client = class_310.method_1551();
        if (client == null) return;
        class_437 current = client.field_1755;
        if (current == null) return;
        if (current instanceof net.minecraft.class_408) return;

        class_304 self = (class_304) (Object) this;
        if (self != client.field_1690.field_1894
                && self != client.field_1690.field_1881
                && self != client.field_1690.field_1913
                && self != client.field_1690.field_1849
                && self != client.field_1690.field_1903
                && self != client.field_1690.field_1832
                && self != client.field_1690.field_1867) {
            return;
        }

        class_3675.class_306 bound = ((KeyBindingAccessor) self).shieldmacemod$getBoundKey();
        if (bound == null || bound.equals(class_3675.field_16237)) return;

        long handle = client.method_22683().method_4490();
        boolean down;
        try {
            if (bound.method_1442() == class_3675.class_307.field_1668) {
                down = GLFW.glfwGetKey(handle, bound.method_1444()) == GLFW.GLFW_PRESS;
            } else if (bound.method_1442() == class_3675.class_307.field_1672) {
                down = GLFW.glfwGetMouseButton(handle, bound.method_1444()) == GLFW.GLFW_PRESS;
            } else {
                return;
            }
        } catch (Throwable ignored) {
            return;
        }

        if (down) cir.setReturnValue(true);
    }
}
