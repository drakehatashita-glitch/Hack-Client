package com.shieldmacemod.mixin;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Exposes the package-private itemUseTimeLeft field for FastUse. */
@Mixin(class_1309.class)
public interface FastUseAccessor {
    @Accessor("itemUseTimeLeft")
    void shieldmacemod$setItemUseTimeLeft(int value);
}
