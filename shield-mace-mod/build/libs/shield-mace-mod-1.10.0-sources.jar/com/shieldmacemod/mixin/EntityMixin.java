package com.shieldmacemod.mixin;

import com.shieldmacemod.ShieldMaceSettings;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Client-side hitbox expander.
 *
 * Overrides {@link class_1297#method_5871()} for OTHER players so that the
 * client's raycast hit-test (used for crosshair targeting and attacks) treats
 * their bounding box as enlarged by the configured number of blocks. The
 * collision box is unaffected, so players are not pushed around.
 *
 * The local player and non-player entities are intentionally left alone.
 */
@Mixin(class_1297.class)
public abstract class EntityMixin {

    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void shieldmacemod$expandHitbox(CallbackInfoReturnable<Float> cir) {
        ShieldMaceSettings settings = ShieldMaceSettings.INSTANCE;
        if (!settings.hitboxExpandEnabled) return;

        class_1297 self = (class_1297) (Object) this;
        if (!(self instanceof class_1657)) return;

        class_310 client = class_310.method_1551();
        if (client == null || self == client.field_1724) return;

        float expansion = Math.max(1, Math.min(50, settings.hitboxExpandTenths)) / 10.0f;
        cir.setReturnValue(expansion);
    }
}
