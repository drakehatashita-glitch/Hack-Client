package com.shieldmacemod;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1684;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_9239;

/**
 * Watches for the player throwing an ender pearl, then computes the angle and
 * timing required for a wind charge fired from the player's hotbar to intercept
 * that pearl mid-flight. When a valid intercept is found it snaps the player's
 * yaw/pitch, fires the wind charge, then restores the slot and rotation.
 */
public class PearlInterceptor {

    // Physics constants (pearl approximation)
    private static final double WIND_CHARGE_SPEED = 1.5;   // blocks/tick (initial throw speed)
    private static final double PEARL_DRAG        = 0.99;
    private static final double PEARL_GRAVITY     = 0.03;

    private static final double SPAWN_DETECT_RADIUS = 4.0;
    private static final int    MAX_AIMING_TICKS    = 40;

    private final ShieldMaceSettings s = ShieldMaceSettings.INSTANCE;

    private enum State { IDLE, AIMING }

    private State state = State.IDLE;
    private class_1684 targetPearl = null;
    private int previousSlot = -1;
    private float originalYaw = 0;
    private float originalPitch = 0;
    private int ticksInAiming = 0;

    private final Set<Integer> trackedPearlIds = new HashSet<>();

    public void toggle(class_310 client) {
        s.pearlInterceptEnabled = !s.pearlInterceptEnabled;
        resetRuntimeState();
        announce(client, s.pearlInterceptEnabled ? "Pearl Catch: ON" : "Pearl Catch: OFF");
    }

    public void resetRuntimeState() {
        class_310 mc = class_310.method_1551();
        if (mc != null && mc.field_1724 != null && previousSlot >= 0 && previousSlot < 9) {
            mc.field_1724.method_31548().method_61496(previousSlot);
        }
        state = State.IDLE;
        targetPearl = null;
        previousSlot = -1;
        ticksInAiming = 0;
        trackedPearlIds.clear();
    }

    private void announce(class_310 client, String msg) {
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470(msg), true);
        }
    }

    public void tick(class_310 client) {
        if (!s.pearlInterceptEnabled) {
            if (state != State.IDLE) resetRuntimeState();
            return;
        }
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            return;
        }

        switch (state) {
            case IDLE   -> handleIdle(client);
            case AIMING -> handleAiming(client);
        }
    }

    // ── Idle: scan for newly spawned ender pearls near the player ────────────

    private void handleIdle(class_310 client) {
        class_746 player = client.field_1724;
        class_638 world = client.field_1687;

        class_238 box = class_238.method_30048(player.method_73189(), 12, 12, 12);
        List<class_1684> nearby = world.method_8390(
                class_1684.class, box, p -> true);

        Set<Integer> currentIds = new HashSet<>();
        class_1684 newPearl = null;
        for (class_1684 p : nearby) {
            currentIds.add(p.method_5628());
            if (!trackedPearlIds.contains(p.method_5628())
                    && p.method_5739(player) < SPAWN_DETECT_RADIUS) {
                newPearl = p;
            }
        }
        // Replace tracked set with what we saw this tick (older ids age out)
        trackedPearlIds.clear();
        trackedPearlIds.addAll(currentIds);

        if (newPearl == null) return;

        int wcSlot = findWindChargeSlot(player);
        if (wcSlot == -1) return;

        previousSlot  = player.method_31548().method_67532();
        originalYaw   = player.method_36454();
        originalPitch = player.method_36455();
        if (wcSlot != previousSlot) {
            player.method_31548().method_61496(wcSlot);
        }
        targetPearl   = newPearl;
        ticksInAiming = 0;
        state         = State.AIMING;
    }

    // ── Aiming: each tick try to fire a wind charge that hits the pearl ─────

    private void handleAiming(class_310 client) {
        ticksInAiming++;
        if (targetPearl == null || targetPearl.method_31481() || ticksInAiming > MAX_AIMING_TICKS) {
            finishAiming(client, false);
            return;
        }

        class_746 player = client.field_1724;
        class_243 eye = player.method_33571();
        class_243 simPos = targetPearl.method_73189();
        class_243 simVel = targetPearl.method_18798();

        int    maxK      = Math.max(10, s.pearlInterceptLookahead);
        double tolerance = Math.max(0.1, s.pearlInterceptToleranceTenths * 0.1);

        double bestErr = Double.MAX_VALUE;
        class_243  bestInterceptPos = null;

        // Find k (wind-charge flight time, in ticks) that best matches the
        // pearl's predicted position k ticks from now.
        for (int k = 1; k <= maxK; k++) {
            simPos = simPos.method_1019(simVel);
            simVel = simVel.method_1021(PEARL_DRAG).method_1031(0, -PEARL_GRAVITY, 0);

            double dist = simPos.method_1020(eye).method_1033();
            double err  = Math.abs(dist - WIND_CHARGE_SPEED * k);
            if (err < bestErr) {
                bestErr = err;
                bestInterceptPos = simPos;
            }
        }

        if (bestInterceptPos == null || bestErr > tolerance) return;

        // Snap-aim, fire, restore rotation
        class_243 delta = bestInterceptPos.method_1020(eye);
        double yaw   = Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350));
        double horiz = Math.sqrt(delta.field_1352 * delta.field_1352 + delta.field_1350 * delta.field_1350);
        double pitch = -Math.toDegrees(Math.atan2(delta.field_1351, horiz));

        player.method_36456((float) yaw);
        player.method_36457((float) pitch);

        class_1799 mainHand = player.method_31548().method_5438(
                player.method_31548().method_67532());
        if (mainHand.method_7909() instanceof class_9239) {
            client.field_1761.method_2919(player, class_1268.field_5808);
            player.method_6104(class_1268.field_5808);
            announce(client, "Pearl Catch fired");
        }

        player.method_36456(originalYaw);
        player.method_36457(originalPitch);

        finishAiming(client, true);
    }

    private void finishAiming(class_310 client, boolean success) {
        class_746 player = client.field_1724;
        if (player != null && previousSlot >= 0 && previousSlot < 9) {
            player.method_31548().method_61496(previousSlot);
        }
        if (!success && player != null) {
            player.method_36456(originalYaw);
            player.method_36457(originalPitch);
        }
        previousSlot  = -1;
        targetPearl   = null;
        ticksInAiming = 0;
        state         = State.IDLE;
    }

    private int findWindChargeSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            if (player.method_31548().method_5438(i).method_7909() instanceof class_9239) {
                return i;
            }
        }
        return -1;
    }
}
