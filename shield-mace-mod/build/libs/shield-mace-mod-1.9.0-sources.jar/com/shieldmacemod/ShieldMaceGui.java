package com.shieldmacemod;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ShieldMaceGui extends class_437 {

    private static final int CARD_WIDTH         = 300;
    private static final int CARD_HEADER_HEIGHT = 28;
    private static final int CARD_INNER_PADDING = 4;
    private static final int CARD_GAP           = 6;
    private static final int WIDGET_HEIGHT      = 20;
    private static final int CONTENT_TOP        = 36;

    private static final int COLOR_TITLE          = 0xFFFFFFFF;
    private static final int COLOR_CARD_BG        = 0xC0202020;
    private static final int COLOR_CARD_BG_HOVER  = 0xC0303040;
    private static final int COLOR_CARD_BORDER    = 0xFF505060;
    private static final int COLOR_LABEL          = 0xFFE0E0E0;
    private static final int COLOR_HINT           = 0xFF9090A0;
    private static final int COLOR_PROMPT         = 0xFFFFD040;

    // GLFW key codes (inlined)
    private static final int GLFW_KEY_UNKNOWN = -1;
    private static final int GLFW_KEY_ESCAPE  = 256;

    private final List<FeatureCard> cards = new ArrayList<>();

    /** Index into cards[] of the feature whose keybind we're currently capturing, or -1. */
    private int pendingRebind = -1;

    public ShieldMaceGui() {
        super(class_2561.method_43470("Shield Mace Mod"));
    }

    @Override
    protected void method_25426() {
        if (cards.isEmpty()) {
            cards.add(new FeatureCard(
                    "Auto Stun Slam",
                    () -> ShieldMaceMod.toggleComboKey,
                    () -> ShieldMaceSettings.INSTANCE.comboEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.comboEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Swap Delay (ticks)", 1, 10,
                                () -> ShieldMaceSettings.INSTANCE.comboSwapDelayTicks,
                                v -> ShieldMaceSettings.INSTANCE.comboSwapDelayTicks = v),
                        new SettingSpec("Cooldown (ticks)", 1, 40,
                                () -> ShieldMaceSettings.INSTANCE.comboCooldownTicks,
                                v -> ShieldMaceSettings.INSTANCE.comboCooldownTicks = v)
                    },
                    new BoolToggleSpec[0],
                    "toggleCombo"
            ));
            cards.add(new FeatureCard(
                    "Breach Swap",
                    () -> ShieldMaceMod.toggleBreachSwapKey,
                    () -> ShieldMaceSettings.INSTANCE.breachSwapEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.breachSwapEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Swap Delay (ticks)", 1, 10,
                                () -> ShieldMaceSettings.INSTANCE.breachSwapDelayTicks,
                                v -> ShieldMaceSettings.INSTANCE.breachSwapDelayTicks = v),
                        new SettingSpec("Cooldown (ticks)", 1, 40,
                                () -> ShieldMaceSettings.INSTANCE.breachSwapCooldownTicks,
                                v -> ShieldMaceSettings.INSTANCE.breachSwapCooldownTicks = v)
                    },
                    new BoolToggleSpec[0],
                    "toggleBreachSwap"
            ));
            cards.add(new FeatureCard(
                    "Shield Breaker",
                    () -> ShieldMaceMod.toggleMaceSpamKey,
                    () -> ShieldMaceSettings.INSTANCE.maceSpamEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.maceSpamEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Clicks per tick", 1, 100,
                                () -> ShieldMaceSettings.INSTANCE.maceSpamClicksPerTick,
                                v -> ShieldMaceSettings.INSTANCE.maceSpamClicksPerTick = v)
                    },
                    new BoolToggleSpec[]{
                        new BoolToggleSpec("Smart Fall Click (U3 shield break)",
                                () -> ShieldMaceSettings.INSTANCE.maceSpamSmartFallClick,
                                v -> ShieldMaceSettings.INSTANCE.maceSpamSmartFallClick = v)
                    },
                    "toggleMaceSpam"
            ));
            cards.add(new FeatureCard(
                    "Silent Aim",
                    () -> ShieldMaceMod.toggleSilentAimKey,
                    () -> ShieldMaceSettings.INSTANCE.silentAimEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.silentAimEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Max angle (deg)", 1, 30,
                                () -> ShieldMaceSettings.INSTANCE.silentAimMaxAngleDegrees,
                                v -> ShieldMaceSettings.INSTANCE.silentAimMaxAngleDegrees = v),
                        new SettingSpec("Strength (%)", 1, 100,
                                () -> ShieldMaceSettings.INSTANCE.silentAimStrengthPct,
                                v -> ShieldMaceSettings.INSTANCE.silentAimStrengthPct = v),
                        new SettingSpec("Range (blocks)", 1, 30,
                                () -> ShieldMaceSettings.INSTANCE.silentAimRangeBlocks,
                                v -> ShieldMaceSettings.INSTANCE.silentAimRangeBlocks = v)
                    },
                    new BoolToggleSpec[0],
                    "toggleSilentAim"
            ));
            cards.add(new FeatureCard(
                    "Hitboxes",
                    () -> ShieldMaceMod.toggleHitboxExpandKey,
                    () -> ShieldMaceSettings.INSTANCE.hitboxExpandEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.hitboxExpandEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Expand x0.1 blocks", 1, 50,
                                () -> ShieldMaceSettings.INSTANCE.hitboxExpandTenths,
                                v -> ShieldMaceSettings.INSTANCE.hitboxExpandTenths = v)
                    },
                    new BoolToggleSpec[0],
                    "toggleHitboxExpand"
            ));
            cards.add(new FeatureCard(
                    "Auto Totem",
                    () -> ShieldMaceMod.toggleAutoTotemKey,
                    () -> ShieldMaceSettings.INSTANCE.autoTotemEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.autoTotemEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Re-check delay (ticks)", 1, 40,
                                () -> ShieldMaceSettings.INSTANCE.autoTotemDelayTicks,
                                v -> ShieldMaceSettings.INSTANCE.autoTotemDelayTicks = v)
                    },
                    new BoolToggleSpec[0],
                    "toggleAutoTotem"
            ));
            cards.add(new FeatureCard(
                    "No Fall",
                    () -> ShieldMaceMod.toggleNoFallKey,
                    () -> ShieldMaceSettings.INSTANCE.noFallEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.noFallEnabled = enabled,
                    new SettingSpec[0],
                    new BoolToggleSpec[0],
                    "toggleNoFall"
            ));
            cards.add(new FeatureCard(
                    "Kill Aura",
                    () -> ShieldMaceMod.toggleKillAuraKey,
                    () -> ShieldMaceSettings.INSTANCE.killAuraEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.killAuraEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Range (blocks)", 1, 8,
                                () -> ShieldMaceSettings.INSTANCE.killAuraRangeBlocks,
                                v -> ShieldMaceSettings.INSTANCE.killAuraRangeBlocks = v),
                        new SettingSpec("Attack delay (ticks)", 1, 20,
                                () -> ShieldMaceSettings.INSTANCE.killAuraDelayTicks,
                                v -> ShieldMaceSettings.INSTANCE.killAuraDelayTicks = v)
                    },
                    new BoolToggleSpec[]{
                        new BoolToggleSpec("Target Players",
                                () -> ShieldMaceSettings.INSTANCE.killAuraTargetPlayers,
                                v -> ShieldMaceSettings.INSTANCE.killAuraTargetPlayers = v),
                        new BoolToggleSpec("Target Hostile Mobs",
                                () -> ShieldMaceSettings.INSTANCE.killAuraTargetHostile,
                                v -> ShieldMaceSettings.INSTANCE.killAuraTargetHostile = v),
                        new BoolToggleSpec("Target Passive Mobs",
                                () -> ShieldMaceSettings.INSTANCE.killAuraTargetPassive,
                                v -> ShieldMaceSettings.INSTANCE.killAuraTargetPassive = v),
                        new BoolToggleSpec("Multi-target (hit all in range)",
                                () -> ShieldMaceSettings.INSTANCE.killAuraTargetAll,
                                v -> ShieldMaceSettings.INSTANCE.killAuraTargetAll = v)
                    },
                    "toggleKillAura"
            ));
            cards.add(new FeatureCard(
                    "Flight",
                    () -> ShieldMaceMod.toggleFlightKey,
                    () -> ShieldMaceSettings.INSTANCE.flightEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.flightEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Speed x0.01", 1, 50,
                                () -> ShieldMaceSettings.INSTANCE.flightSpeedTenths,
                                v -> ShieldMaceSettings.INSTANCE.flightSpeedTenths = v)
                    },
                    new BoolToggleSpec[0],
                    "toggleFlight"
            ));
            cards.add(new FeatureCard(
                    "Mace Kill",
                    () -> ShieldMaceMod.toggleHeightSmashKey,
                    () -> ShieldMaceSettings.INSTANCE.heightSmashEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.heightSmashEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Drop packets", 1, 40,
                                () -> ShieldMaceSettings.INSTANCE.heightSmashPackets,
                                v -> ShieldMaceSettings.INSTANCE.heightSmashPackets = v),
                        new SettingSpec("Y per packet (blocks)", 1, 9,
                                () -> ShieldMaceSettings.INSTANCE.heightSmashDropPerPacket,
                                v -> ShieldMaceSettings.INSTANCE.heightSmashDropPerPacket = v)
                    },
                    new BoolToggleSpec[0],
                    "toggleHeightSmash"
            ));
            cards.add(new FeatureCard(
                    "Blink",
                    () -> ShieldMaceMod.toggleBlinkKey,
                    () -> ShieldMaceSettings.INSTANCE.blinkEnabled,
                    enabled -> {
                        // Route through the feature so toggling from the GUI
                        // also flushes / clears the queued packets correctly.
                        if (ShieldMaceMod.feature != null
                                && ShieldMaceSettings.INSTANCE.blinkEnabled != enabled) {
                            ShieldMaceMod.feature.toggleBlink(class_310.method_1551());
                        } else {
                            ShieldMaceSettings.INSTANCE.blinkEnabled = enabled;
                        }
                    },
                    new SettingSpec[0],
                    new BoolToggleSpec[0],
                    "toggleBlink"
            ));
            cards.add(new FeatureCard(
                    "Pearl Catch",
                    () -> ShieldMaceMod.togglePearlInterceptKey,
                    () -> ShieldMaceSettings.INSTANCE.pearlInterceptEnabled,
                    enabled -> ShieldMaceSettings.INSTANCE.pearlInterceptEnabled = enabled,
                    new SettingSpec[]{
                        new SettingSpec("Tolerance x0.1 blocks", 1, 30,
                                () -> ShieldMaceSettings.INSTANCE.pearlInterceptToleranceTenths,
                                v -> ShieldMaceSettings.INSTANCE.pearlInterceptToleranceTenths = v),
                        new SettingSpec("Lookahead (ticks)", 10, 80,
                                () -> ShieldMaceSettings.INSTANCE.pearlInterceptLookahead,
                                v -> ShieldMaceSettings.INSTANCE.pearlInterceptLookahead = v)
                    },
                    new BoolToggleSpec[0],
                    "togglePearlIntercept"
            ));
        }

        layoutAndAddWidgets();
    }

    private void layoutAndAddWidgets() {
        method_37067();

        int cardX = (this.field_22789 - CARD_WIDTH) / 2;
        int y = CONTENT_TOP;

        for (int i = 0; i < cards.size(); i++) {
            FeatureCard card = cards.get(i);
            card.x = cardX;
            card.y = y;

            // ── Header row (always visible): ON/OFF button on the left ─────────
            int toggleBtnW = 50;
            class_4185 toggleBtn = class_4185.method_46430(
                    class_2561.method_43470(card.isEnabled() ? "ON" : "OFF"),
                    b -> {
                        boolean newVal = !card.isEnabled();
                        card.setEnabled(newVal);
                        // Reset internal state so toggling mid-action can't glitch
                        if (ShieldMaceMod.feature != null) {
                            ShieldMaceMod.feature.resetRuntimeState();
                        }
                        if (ShieldMaceMod.pearlInterceptor != null) {
                            ShieldMaceMod.pearlInterceptor.resetRuntimeState();
                        }
                        layoutAndAddWidgets();
                    })
                .method_46434(card.x + CARD_INNER_PADDING,
                            card.y + (CARD_HEADER_HEIGHT - WIDGET_HEIGHT) / 2,
                            toggleBtnW, WIDGET_HEIGHT)
                .method_46431();
            method_37063(toggleBtn);

            // Card body height (computed to know where the next card goes)
            int cardHeight = CARD_HEADER_HEIGHT;

            if (card.expanded) {
                int rowY = card.y + CARD_HEADER_HEIGHT + CARD_INNER_PADDING;

                // ── Keybind row ───────────────────────────────────────────────
                int kbBtnX = card.x + CARD_INNER_PADDING + 90;
                int kbBtnW = CARD_WIDTH - CARD_INNER_PADDING * 2 - 90;
                final int cardIdx = i;
                class_4185 keybindBtn = class_4185.method_46430(
                        class_2561.method_43470(keybindButtonLabel(cardIdx)),
                        b -> {
                            pendingRebind = cardIdx;
                            layoutAndAddWidgets();
                        })
                    .method_46434(kbBtnX, rowY, kbBtnW, WIDGET_HEIGHT)
                    .method_46431();
                method_37063(keybindBtn);
                rowY += WIDGET_HEIGHT + CARD_INNER_PADDING;

                // ── Bool toggle rows ──────────────────────────────────────────
                for (BoolToggleSpec spec : card.boolToggles) {
                    final BoolToggleSpec specRef = spec;
                    int btnW = 60;
                    int btnX = card.x + CARD_WIDTH - CARD_INNER_PADDING - btnW;
                    class_4185 subToggleBtn = class_4185.method_46430(
                            class_2561.method_43470(specRef.getter.get() ? "ON" : "OFF"),
                            b -> {
                                specRef.setter.set(!specRef.getter.get());
                                layoutAndAddWidgets();
                            })
                        .method_46434(btnX, rowY, btnW, WIDGET_HEIGHT)
                        .method_46431();
                    method_37063(subToggleBtn);
                    rowY += WIDGET_HEIGHT + CARD_INNER_PADDING;
                }

                // ── Setting sliders ───────────────────────────────────────────
                for (SettingSpec spec : card.settings) {
                    method_37063(new IntSliderWidget(
                            card.x + CARD_INNER_PADDING, rowY,
                            CARD_WIDTH - CARD_INNER_PADDING * 2, WIDGET_HEIGHT,
                            spec.label, spec.min, spec.max,
                            spec.getter.getAsInt(),
                            spec.setter
                    ));
                    rowY += WIDGET_HEIGHT + CARD_INNER_PADDING;
                }

                cardHeight = rowY - card.y;
            }

            card.height = cardHeight;
            y += cardHeight + CARD_GAP;
        }

        // ── Done button at the bottom ─────────────────────────────────────────
        int doneW = 100;
        class_4185 doneBtn = class_4185.method_46430(
                class_2561.method_43470("Done"),
                b -> method_25419())
            .method_46434((this.field_22789 - doneW) / 2, y + 6, doneW, WIDGET_HEIGHT)
            .method_46431();
        method_37063(doneBtn);
    }

    private String keybindButtonLabel(int idx) {
        if (pendingRebind == idx) return "> Press a key (Esc to clear) <";
        class_304 kb = cards.get(idx).keyBindingSupplier.get();
        return "Keybind: " + kb.method_16007().getString();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        // Title
        context.method_27534(this.field_22793, this.field_22785,
                this.field_22789 / 2, 14, COLOR_TITLE);

        // Card backgrounds, borders, labels, hints
        for (int i = 0; i < cards.size(); i++) {
            FeatureCard card = cards.get(i);
            boolean hover = mouseX >= card.x && mouseX <= card.x + CARD_WIDTH
                    && mouseY >= card.y && mouseY <= card.y + card.height;

            int bg = hover ? COLOR_CARD_BG_HOVER : COLOR_CARD_BG;
            context.method_25294(card.x, card.y, card.x + CARD_WIDTH, card.y + card.height, bg);
            // 1-px border
            context.method_25294(card.x, card.y, card.x + CARD_WIDTH, card.y + 1, COLOR_CARD_BORDER);
            context.method_25294(card.x, card.y + card.height - 1,
                    card.x + CARD_WIDTH, card.y + card.height, COLOR_CARD_BORDER);
            context.method_25294(card.x, card.y, card.x + 1, card.y + card.height, COLOR_CARD_BORDER);
            context.method_25294(card.x + CARD_WIDTH - 1, card.y,
                    card.x + CARD_WIDTH, card.y + card.height, COLOR_CARD_BORDER);

            // Feature name (right of the ON/OFF button)
            int nameX = card.x + CARD_INNER_PADDING + 50 + 8;
            int nameY = card.y + (CARD_HEADER_HEIGHT - this.field_22793.field_2000) / 2;
            context.method_27535(this.field_22793,
                    class_2561.method_43470(card.name), nameX, nameY, COLOR_LABEL);

            // Right-side hint
            String hint = card.expanded ? "right-click to collapse" : "right-click to expand";
            int hintW = this.field_22793.method_1727(hint);
            context.method_27535(this.field_22793, class_2561.method_43470(hint),
                    card.x + CARD_WIDTH - CARD_INNER_PADDING - hintW, nameY, COLOR_HINT);

            // "Keybind:" label and bool-toggle labels inside expanded card
            if (card.expanded) {
                int rowY = card.y + CARD_HEADER_HEIGHT + CARD_INNER_PADDING;
                int labelY = rowY + (WIDGET_HEIGHT - this.field_22793.field_2000) / 2;
                context.method_27535(this.field_22793, class_2561.method_43470("Keybind"),
                        card.x + CARD_INNER_PADDING, labelY, COLOR_LABEL);
                rowY += WIDGET_HEIGHT + CARD_INNER_PADDING;

                for (BoolToggleSpec spec : card.boolToggles) {
                    int boolLabelY = rowY + (WIDGET_HEIGHT - this.field_22793.field_2000) / 2;
                    context.method_27535(this.field_22793,
                            class_2561.method_43470(spec.label),
                            card.x + CARD_INNER_PADDING, boolLabelY, COLOR_LABEL);
                    rowY += WIDGET_HEIGHT + CARD_INNER_PADDING;
                }

                if (pendingRebind == i) {
                    int promptY = card.y + card.height + 2;
                    context.method_27534(this.field_22793,
                            class_2561.method_43470("Press a key to rebind, or Esc to clear"),
                            card.x + CARD_WIDTH / 2, promptY, COLOR_PROMPT);
                }
            }
        }
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

        // If we're capturing a keybind and the user clicks a mouse button,
        // bind to that mouse button.
        if (pendingRebind != -1) {
            class_304 kb = cards.get(pendingRebind).keyBindingSupplier.get();
            kb.method_1422(class_3675.class_307.field_1672.method_1447(button));
            class_304.method_1426();
            persistKeybinds();
            pendingRebind = -1;
            layoutAndAddWidgets();
            return true;
        }

        if (super.method_25402(click, doubled)) return true;

        // Right-click on a card header → expand/collapse
        if (button == 1) {
            for (FeatureCard card : cards) {
                if (mouseX >= card.x && mouseX <= card.x + CARD_WIDTH
                        && mouseY >= card.y && mouseY <= card.y + CARD_HEADER_HEIGHT) {
                    card.expanded = !card.expanded;
                    layoutAndAddWidgets();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (pendingRebind != -1) {
            class_304 kb = cards.get(pendingRebind).keyBindingSupplier.get();
            if (input.comp_4795() == GLFW_KEY_ESCAPE) {
                kb.method_1422(class_3675.field_16237);
            } else {
                kb.method_1422(class_3675.method_15985(input));
            }
            class_304.method_1426();
            persistKeybinds();
            pendingRebind = -1;
            layoutAndAddWidgets();
            return true;
        }
        return super.method_25404(input);
    }

    private void persistKeybinds() {
        class_310 mc = class_310.method_1551();
        if (mc != null && mc.field_1690 != null) {
            mc.field_1690.method_1640();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // ── Internal types ────────────────────────────────────────────────────────

    @FunctionalInterface
    private interface BoolGetter { boolean get(); }
    @FunctionalInterface
    private interface BoolSetter { void set(boolean v); }
    @FunctionalInterface
    private interface IntGetter { int getAsInt(); }
    @FunctionalInterface
    private interface KeyBindingSupplier { class_304 get(); }

    private static final class SettingSpec {
        final String label;
        final int min;
        final int max;
        final IntGetter getter;
        final IntConsumer setter;

        SettingSpec(String label, int min, int max, IntGetter getter, IntConsumer setter) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.getter = getter;
            this.setter = setter;
        }
    }

    private static final class BoolToggleSpec {
        final String label;
        final BoolGetter getter;
        final BoolSetter setter;

        BoolToggleSpec(String label, BoolGetter getter, BoolSetter setter) {
            this.label = label;
            this.getter = getter;
            this.setter = setter;
        }
    }

    private static final class FeatureCard {
        final String name;
        final KeyBindingSupplier keyBindingSupplier;
        final BoolGetter enabledGetter;
        final BoolSetter enabledSetter;
        final SettingSpec[] settings;
        final BoolToggleSpec[] boolToggles;
        @SuppressWarnings("unused") final String translationSuffix;

        boolean expanded = false;
        int x, y, height;

        FeatureCard(String name,
                    KeyBindingSupplier keyBindingSupplier,
                    BoolGetter enabledGetter,
                    BoolSetter enabledSetter,
                    SettingSpec[] settings,
                    BoolToggleSpec[] boolToggles,
                    String translationSuffix) {
            this.name = name;
            this.keyBindingSupplier = keyBindingSupplier;
            this.enabledGetter = enabledGetter;
            this.enabledSetter = enabledSetter;
            this.settings = settings;
            this.boolToggles = boolToggles;
            this.translationSuffix = translationSuffix;
        }

        boolean isEnabled() { return enabledGetter.get(); }
        void setEnabled(boolean v) { enabledSetter.set(v); }
    }

    /** A SliderWidget that maps the [0..1] value to an integer in [min..max]. */
    private static final class IntSliderWidget extends class_357 {
        private final int min;
        private final int max;
        private final String label;
        private final IntConsumer onChange;
        private int currentValue;

        IntSliderWidget(int x, int y, int width, int height, String label,
                        int min, int max, int initial, IntConsumer onChange) {
            super(x, y, width, height,
                    class_2561.method_43470(label + ": " + initial),
                    (initial - min) / (double) (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.currentValue = clamp(initial);
            this.onChange = onChange;
            method_25346();
        }

        private int clamp(int v) {
            return Math.max(min, Math.min(max, v));
        }

        @Override
        protected void method_25346() {
            currentValue = clamp((int) Math.round(min + field_22753 * (max - min)));
            method_25355(class_2561.method_43470(label + ": " + currentValue));
        }

        @Override
        protected void method_25344() {
            currentValue = clamp((int) Math.round(min + field_22753 * (max - min)));
            onChange.accept(currentValue);
        }
    }
}
