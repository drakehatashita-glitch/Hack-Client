package com.shieldmacemod;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9362;

public class ShieldMaceFeature {

    private enum State {
        IDLE,
        // Auto-combo states
        AXE_SWUNG,
        WAITING_FOR_MACE,
        // Click-triggered shield-break states
        SHIELD_BREAK_AXE_SWUNG,
        // Breach-swap states
        BREACH_SWAP_RETURN
    }

    private final ShieldMaceSettings s = ShieldMaceSettings.INSTANCE;

    private State state           = State.IDLE;
    private int   delayTimer      = 0;
    private int   cooldownTimer   = 0;

    // Slot to restore after a click-triggered swap (shield break or breach swap)
    private int previousSlot      = 0;

    // Edge-detection for attack click (avoids consuming the key event)
    private boolean wasAttackPressed = false;

    // Auto-totem rate-limiter (ticks remaining until next swap attempt)
    private int autoTotemCooldown = 0;

    // Kill-aura rate-limiter (ticks remaining until next attack)
    private int killAuraCooldown = 0;

    // ── Blink state ──────────────────────────────────────────────────────
    // While blinkEnabled, every outgoing PlayerMoveC2SPacket is intercepted
    // by ClientPlayNetworkHandlerMixin and pushed onto this queue instead
    // of being sent to the server. When blink is turned OFF, the queue is
    // drained in FIFO order back through the network handler so the server
    // fast-forwards the player's tracked position to where they actually
    // are now. `blinkBypass` is set to true while we are flushing so the
    // mixin lets those replays through instead of re-queuing them.
    private final Deque<class_2596<?>> blinkQueue = new ArrayDeque<>();
    private boolean blinkBypass = false;

    public void toggleCombo(class_310 client) {
        s.comboEnabled = !s.comboEnabled;
        resetRuntimeState();
        announce(client, s.comboEnabled ? "Auto Stun Slam: ON" : "Auto Stun Slam: OFF");
    }

    public void toggleBreachSwap(class_310 client) {
        s.breachSwapEnabled = !s.breachSwapEnabled;
        resetRuntimeState();
        announce(client, s.breachSwapEnabled ? "Breach Swap: ON" : "Breach Swap: OFF");
    }

    public void toggleMaceSpam(class_310 client) {
        s.maceSpamEnabled = !s.maceSpamEnabled;
        resetRuntimeState();
        announce(client, s.maceSpamEnabled ? "Shield Breaker: ON" : "Shield Breaker: OFF");
    }

    public void toggleSilentAim(class_310 client) {
        s.silentAimEnabled = !s.silentAimEnabled;
        announce(client, s.silentAimEnabled ? "Silent Aim: ON" : "Silent Aim: OFF");
    }

    public void toggleHeightSmash(class_310 client) {
        s.heightSmashEnabled = !s.heightSmashEnabled;
        announce(client, s.heightSmashEnabled ? "Mace Kill: ON" : "Mace Kill: OFF");
    }

    public void toggleHitboxExpand(class_310 client) {
        s.hitboxExpandEnabled = !s.hitboxExpandEnabled;
        announce(client, s.hitboxExpandEnabled ? "Hitboxes: ON" : "Hitboxes: OFF");
    }

    public void toggleAutoTotem(class_310 client) {
        s.autoTotemEnabled = !s.autoTotemEnabled;
        autoTotemCooldown = 0;
        announce(client, s.autoTotemEnabled ? "Auto Totem: ON" : "Auto Totem: OFF");
    }

    public void toggleNoFall(class_310 client) {
        s.noFallEnabled = !s.noFallEnabled;
        announce(client, s.noFallEnabled ? "No Fall: ON" : "No Fall: OFF");
    }

    public void toggleKillAura(class_310 client) {
        s.killAuraEnabled = !s.killAuraEnabled;
        killAuraCooldown = 0;
        announce(client, s.killAuraEnabled ? "Kill Aura: ON" : "Kill Aura: OFF");
    }

    public void toggleBlink(class_310 client) {
        s.blinkEnabled = !s.blinkEnabled;
        if (!s.blinkEnabled) {
            // Disabling: flush every queued movement packet so the server
            // fast-forwards the player's tracked position to where they
            // actually are now. The bypass flag prevents the outgoing
            // mixin from re-queuing the packets we are replaying here.
            int flushed = blinkQueue.size();
            if (client.field_1724 != null && client.field_1724.field_3944 != null) {
                blinkBypass = true;
                try {
                    while (!blinkQueue.isEmpty()) {
                        client.field_1724.field_3944.method_52787(blinkQueue.pollFirst());
                    }
                } finally {
                    blinkBypass = false;
                }
            } else {
                blinkQueue.clear();
            }
            announce(client, "Blink: OFF (flushed " + flushed + " packets)");
        } else {
            blinkQueue.clear();
            announce(client, "Blink: ON");
        }
    }

    /** Called from {@code ClientPlayNetworkHandlerMixin}. Returns true if
     *  the packet was queued and the original send should be cancelled. */
    public boolean queueBlinkPacket(class_2596<?> packet) {
        if (!s.blinkEnabled || blinkBypass) return false;
        if (!(packet instanceof class_2828)) return false;
        // Cap the queue so a player who leaves blink on for hours doesn't
        // OOM the client. 24000 packets ≈ 20 minutes of movement at 20 tps.
        if (blinkQueue.size() >= 24000) return false;
        blinkQueue.addLast(packet);
        return true;
    }

    public void toggleFlight(class_310 client) {
        s.flightEnabled = !s.flightEnabled;
        if (client.field_1724 != null) {
            var abilities = client.field_1724.method_31549();
            if (s.flightEnabled) {
                abilities.field_7478 = true;
                abilities.method_7248(Math.max(1, Math.min(50, s.flightSpeedTenths)) * 0.01f);
            } else {
                // Restore vanilla state — only creative players keep flight.
                abilities.field_7478 = client.field_1724.method_68878();
                abilities.field_7479 = abilities.field_7478 && abilities.field_7479;
                abilities.method_7248(0.05f);
            }
        }
        announce(client, s.flightEnabled ? "Flight: ON (double-tap space)" : "Flight: OFF");
    }

    public void resetRuntimeState() {
        state                    = State.IDLE;
        delayTimer               = 0;
        cooldownTimer            = 0;
        wasAttackPressed         = false;
        smartFallTicksSinceClick = 0;
    }

    private void announce(class_310 client, String msg) {
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470(msg), true);
        }
    }

    public void tick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) return;

        // ── Auto Totem runs independently of the other features ─────────────
        if (s.autoTotemEnabled) {
            tickAutoTotem(client);
        }

        // ── Flight is a continuous "force" — re-applied every tick so the
        //     server's ability sync packets can't take it away mid-flight ──
        if (s.flightEnabled) {
            tickFlight(client);
        }

        // ── Kill Aura runs independently of the combo / spam state machine ─
        if (s.killAuraEnabled) {
            tickKillAura(client);
        }

        // ── Silent Aim runs independently of the other features ──────────────
        if (s.silentAimEnabled) {
            tickSilentAim(client);
        }

        // ── Click edge-detection (observe only — does NOT consume the key event)
        //     Tracked every tick so Height Smash can fire even when no other
        //     combo/breach/spam features are on. ──
        boolean isAttackPressed = client.field_1690.field_1886.method_1434();
        boolean clickedThisTick = isAttackPressed && !wasAttackPressed;
        wasAttackPressed = isAttackPressed;

        // ── Feature 6 (height smash): fires once per click while holding a mace ──
        if (s.heightSmashEnabled && clickedThisTick) {
            tryHeightSmash(client);
        }

        if (!s.comboEnabled && !s.breachSwapEnabled && !s.maceSpamEnabled) return;

        // ── Feature 4 (mace spam): runs every tick, independent of state machine ──
        if (s.maceSpamEnabled) {
            tickMaceSpam(client);
        }

        if (cooldownTimer > 0) {
            cooldownTimer--;
            return;
        }

        switch (state) {
            case IDLE -> handleIdle(client, clickedThisTick);
            case AXE_SWUNG -> {
                if (delayTimer > 0) delayTimer--;
                else state = State.WAITING_FOR_MACE;
            }
            case WAITING_FOR_MACE        -> handleMaceSwing(client);
            case SHIELD_BREAK_AXE_SWUNG  -> handleSwapBackReturn(client, s.comboCooldownTicks);
            case BREACH_SWAP_RETURN      -> handleSwapBackReturn(client, s.breachSwapCooldownTicks);
        }
    }

    // ── Idle: breach-swap → click-on-shield → auto-combo ──────────────────────

    private void handleIdle(class_310 client, boolean clickedThisTick) {
        // Priority 1: breach-mace swap on any attack against a mob or player
        if (s.breachSwapEnabled && clickedThisTick) {
            class_1309 livingTarget = getLookedAtLiving(client);
            if (livingTarget != null) {
                int breachSlot  = findBreachMaceSlot(client);
                int currentSlot = client.field_1724.method_31548().method_67532();

                if (breachSlot != -1 && breachSlot != currentSlot) {
                    previousSlot = currentSlot;
                    client.field_1724.method_31548().method_61496(breachSlot);
                    client.field_1761.method_2918(client.field_1724, livingTarget);
                    client.field_1724.method_6104(class_1268.field_5808);

                    state      = State.BREACH_SWAP_RETURN;
                    delayTimer = s.breachSwapDelayTicks;
                    return;
                }
            }
        }

        // Features 1 & 2 are gated by the combo toggle
        if (!s.comboEnabled) return;

        class_1657 target = getLookedAtPlayer(client);
        if (target == null) return;

        // Priority 2: if the user clicked AND target is actively blocking → axe swap-and-return
        if (clickedThisTick && target.method_6039()) {
            int axeSlot = findAxeSlot(client);
            if (axeSlot != -1) {
                previousSlot = client.field_1724.method_31548().method_67532();
                client.field_1724.method_31548().method_61496(axeSlot);
                client.field_1761.method_2918(client.field_1724, target);
                client.field_1724.method_6104(class_1268.field_5808);

                state      = State.SHIELD_BREAK_AXE_SWUNG;
                delayTimer = s.comboSwapDelayTicks;
                return;
            }
        }

        // Priority 3: auto-combo (fires automatically when looking at any player)
        int axeSlot = findAxeSlot(client);
        if (axeSlot == -1) return;

        client.field_1724.method_31548().method_61496(axeSlot);
        client.field_1761.method_2918(client.field_1724, target);
        client.field_1724.method_6104(class_1268.field_5808);

        state      = State.AXE_SWUNG;
        delayTimer = s.comboSwapDelayTicks;
    }

    // ── Auto-combo: after delay equip best mace and swing ─────────────────────

    private void handleMaceSwing(class_310 client) {
        class_1657 target = getLookedAtPlayer(client);
        if (target == null) {
            state = State.IDLE;
            return;
        }

        int maceSlot = findBestMaceSlot(client);
        if (maceSlot == -1) {
            state = State.IDLE;
            return;
        }

        client.field_1724.method_31548().method_61496(maceSlot);
        client.field_1761.method_2918(client.field_1724, target);
        client.field_1724.method_6104(class_1268.field_5808);

        state         = State.IDLE;
        cooldownTimer = s.comboCooldownTicks;
    }

    // ── Click-shield-break / breach-swap: after delay swap back to previous slot ──

    private void handleSwapBackReturn(class_310 client, int cooldownTicks) {
        if (delayTimer > 0) {
            delayTimer--;
            return;
        }

        client.field_1724.method_31548().method_61496(previousSlot);

        state         = State.IDLE;
        cooldownTimer = cooldownTicks;
    }

    // ── Feature 4: mace spam (N clicks per tick on a player target) ───────────

    private static final double MACE_BASE_DAMAGE      = 5.0;   // approximate base attack damage
    private static final double SHIELD_BASE_DURABILITY = 336.0;
    private static final double UNBREAKING_3_FACTOR   = 4.0;   // expected dur usage divisor (lvl+1)
    private static final double SMART_TARGET_FD       = 3.0;   // optimal fd per click (end of 4-dmg/block zone)
    private static final double SMART_MIN_FD          = 1.5;   // minimum fd to actually trigger smash

    private int smartFallTicksSinceClick = 0;

    private void tickMaceSpam(class_310 client) {
        class_1799 mainHand = client.field_1724.method_31548().method_5438(
                client.field_1724.method_31548().method_67532());
        if (!(mainHand.method_7909() instanceof class_9362)) return;

        if (s.maceSpamSmartFallClick) {
            tickSmartFallClick(client);
        } else {
            // Original behavior: N clicks per tick at a player target
            class_1657 target = getLookedAtPlayer(client);
            if (target == null) return;
            int n = Math.max(1, s.maceSpamClicksPerTick);
            for (int i = 0; i < n; i++) {
                client.field_1761.method_2918(client.field_1724, target);
            }
            client.field_1724.method_6104(class_1268.field_5808);
        }
    }

    private void tickSmartFallClick(class_310 client) {
        // Reset cadence when on the ground — fresh fall coming
        if (client.field_1724.method_24828()) {
            smartFallTicksSinceClick = 0;
            return;
        }

        double fd = client.field_1724.field_6017;
        if (fd <= 0) return;

        class_1657 target = getLookedAtPlayer(client);
        if (target == null) {
            smartFallTicksSinceClick++;
            return;
        }

        // Current downward speed (positive when falling)
        double fallSpeed = -client.field_1724.method_18798().field_1351;
        if (fallSpeed < 0.05) {
            // Going up or barely moving — no smash possible
            smartFallTicksSinceClick++;
            return;
        }

        // Time (in ticks) for fd to grow back to SMART_TARGET_FD after a smash reset
        int interval = Math.max(1, (int) Math.ceil(SMART_TARGET_FD / fallSpeed));

        smartFallTicksSinceClick++;

        // Estimated smash damage at SMART_TARGET_FD (mace bonus = 4*min(fd,3))
        double smashDmg = MACE_BASE_DAMAGE + 4.0 * Math.min(SMART_TARGET_FD, 3.0);
        double expectedDurPerHit = smashDmg / UNBREAKING_3_FACTOR;
        int hitsToBreak = (int) Math.ceil(SHIELD_BASE_DURABILITY / Math.max(0.1, expectedDurPerHit));

        // Live action-bar readout so the player can see the calculation
        String msg = String.format(
                "Smart Fall: fd=%.1f  v=%.2f b/t  click every %d t  ~%d hits to break U3 shield",
                fd, fallSpeed, interval, hitsToBreak);
        client.field_1724.method_7353(class_2561.method_43470(msg), true);

        // Click only if enough ticks have passed AND fd is actually past the smash threshold
        if (smartFallTicksSinceClick >= interval && fd >= SMART_MIN_FD) {
            client.field_1761.method_2918(client.field_1724, target);
            client.field_1724.method_6104(class_1268.field_5808);
            smartFallTicksSinceClick = 0;
        }
    }

    // ── Feature 10: kill aura ────────────────────────────────────────────────
    // Every `killAuraDelayTicks` ticks, find the closest entity inside
    // `killAuraRangeBlocks` that matches the configured target classes
    // (players / hostile mobs / passive mobs) and attack it. Distance is
    // measured to the entity's bounding-box edge so the range matches the
    // server's own reach check.
    private void tickKillAura(class_310 client) {
        if (killAuraCooldown > 0) {
            killAuraCooldown--;
            return;
        }
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) return;

        double range = Math.max(1, Math.min(8, s.killAuraRangeBlocks));
        class_243 eye = client.field_1724.method_33571();
        class_238 searchBox = class_238.method_30048(eye, range * 2, range * 2, range * 2);

        List<class_1309> candidates = client.field_1687.method_8390(
                class_1309.class, searchBox, e -> {
                    if (e == client.field_1724 || !e.method_5805()) return false;
                    if (e instanceof class_1657 p) {
                        if (p.method_7325()) return false;
                        if (p.method_68878()) return false;
                        return s.killAuraTargetPlayers;
                    }
                    if (e instanceof class_1588) return s.killAuraTargetHostile;
                    if (e instanceof class_1296) return s.killAuraTargetPassive;
                    return false;
                });

        double rangeSq = range * range;

        if (s.killAuraTargetAll) {
            // Multi-target: attack every valid entity inside the range
            // this tick, then start the cooldown so we don't hammer the
            // server every single tick.
            int hits = 0;
            for (class_1309 e : candidates) {
                double distSq = e.method_5829().method_49271(eye);
                if (distSq > rangeSq) continue;
                client.field_1761.method_2918(client.field_1724, e);
                hits++;
            }
            if (hits > 0) {
                client.field_1724.method_6104(class_1268.field_5808);
                killAuraCooldown = Math.max(1, s.killAuraDelayTicks);
            }
            return;
        }

        class_1309 best = null;
        double bestDistSq = rangeSq;
        for (class_1309 e : candidates) {
            // Use bounding-box distance from the eye so the range check
            // mirrors what the server does on attack.
            double distSq = e.method_5829().method_49271(eye);
            if (distSq < bestDistSq) {
                bestDistSq = distSq;
                best = e;
            }
        }
        if (best == null) return;

        client.field_1761.method_2918(client.field_1724, best);
        client.field_1724.method_6104(class_1268.field_5808);
        killAuraCooldown = Math.max(1, s.killAuraDelayTicks);
    }

    // ── Feature 11: flight ────────────────────────────────────────────────────
    // Each tick, force the local player's allowFlying ability on and re-apply
    // the configured fly-speed. The server may overwrite these via its own
    // PlayerAbilitiesS2CPacket, so re-applying every tick keeps flight active
    // until the user disables the toggle. The user takes off / lands by
    // double-tapping space, exactly like vanilla creative mode.
    private void tickFlight(class_310 client) {
        if (client.field_1724 == null) return;
        var abilities = client.field_1724.method_31549();
        abilities.field_7478 = true;
        abilities.method_7248(Math.max(1, Math.min(50, s.flightSpeedTenths)) * 0.01f);
    }

    // ── Feature 8: auto totem ────────────────────────────────────────────────
    // Every `autoTotemDelayTicks` ticks, if the offhand isn't already a Totem
    // of Undying, scan the hotbar + main inventory for one and send a slot
    // swap (button 40 = offhand swap key) so it ends up in the offhand. Any
    // item previously in the offhand goes back to the totem's old slot.
    private void tickAutoTotem(class_310 client) {
        if (autoTotemCooldown > 0) {
            autoTotemCooldown--;
            return;
        }
        if (client.field_1724 == null || client.field_1761 == null) return;

        class_1799 offhand = client.field_1724.method_6079();
        if (offhand.method_31574(class_1802.field_8288)) return;

        var inv = client.field_1724.method_31548();
        int totemInvIndex = -1;
        // PlayerInventory: 0..8 hotbar, 9..35 main. Skip armor (36..39) and offhand (40).
        for (int i = 0; i < 36; i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_8288)) {
                totemInvIndex = i;
                break;
            }
        }
        if (totemInvIndex < 0) return;

        // Map PlayerInventory index → PlayerScreenHandler slot id.
        // Hotbar (0..8) lives at screen slots 36..44; main inventory (9..35)
        // maps 1:1 (slot ids 9..35).
        int screenSlot = (totemInvIndex < 9) ? totemInvIndex + 36 : totemInvIndex;

        client.field_1761.method_2906(
                client.field_1724.field_7498.field_7763,
                screenSlot,
                40,                       // 40 = offhand swap key (matches F key default)
                class_1713.field_7791,
                client.field_1724);

        autoTotemCooldown = Math.max(1, s.autoTotemDelayTicks);
    }

    // ── Feature 6: height smash ──────────────────────────────────────────────
    // Sends a burst of fake position packets that drop the server-tracked Y by
    // (heightSmashPackets × heightSmashDropPerPacket) blocks with onGround=false,
    // so the server accumulates a large fall-distance. Then sends matching
    // upward packets to restore Y to the original (so the server's reach check
    // on the attack still passes) and finally sends the attack — at which point
    // the mace's smash bonus is applied at the inflated fall-distance.
    //
    // NOTE: the player's server-side fall-distance remains high after this
    // burst, so when the client's normal movement packets next report
    // onGround=true, the server applies that fall damage to the attacker.
    // Use with high HP / Resistance / lots of armor.
    private void tryHeightSmash(class_310 client) {
        var player = client.field_1724;
        if (player == null || player.field_3944 == null) return;

        // Must be holding a mace
        class_1799 mainHand = player.method_31548().method_5438(
                player.method_31548().method_67532());
        if (!(mainHand.method_7909() instanceof class_9362)) return;

        // Must be looking at a living target
        class_1309 target = getLookedAtLiving(client);
        if (target == null) return;

        int packets = Math.max(1, Math.min(40, s.heightSmashPackets));
        double dropPerPacket = Math.max(1, Math.min(9, s.heightSmashDropPerPacket));

        double origX = player.method_23317();
        double origY = player.method_23318();
        double origZ = player.method_23321();

        var net = player.field_3944;

        // Phase 1: drop server-tracked Y in small steps, accumulating fall-distance.
        double fakeY = origY;
        for (int i = 0; i < packets; i++) {
            fakeY -= dropPerPacket;
            net.method_52787(new class_2828.class_2829(
                    origX, fakeY, origZ, false, false));
        }

        // Phase 2: rise back to the original Y so the attack's reach check passes.
        // onGround=false the whole way so the server keeps the accumulated
        // fall-distance instead of resetting it on landing.
        for (int i = 0; i < packets; i++) {
            fakeY += dropPerPacket;
            net.method_52787(new class_2828.class_2829(
                    origX, fakeY, origZ, false, false));
        }

        // Phase 3: do the actual attack with the mace.
        client.field_1761.method_2918(player, target);
        player.method_6104(class_1268.field_5808);

        double fakeFall = packets * dropPerPacket;
        client.field_1724.method_7353(
                class_2561.method_43470(String.format("Mace Kill: faked fd ≈ %.0f blocks", fakeFall)),
                true);
    }

    // ── Feature 5: silent aim (soft camera assist when crosshair is close) ───

    private void tickSilentAim(class_310 client) {
        class_243 eye = client.field_1724.method_33571();

        double maxRange    = Math.max(1, s.silentAimRangeBlocks);
        double maxAngleDeg = Math.max(1, s.silentAimMaxAngleDegrees);
        double strength    = Math.max(0.01, s.silentAimStrengthPct / 100.0);

        // Reject any target whose direction makes a wider cone with the
        // current look vector than the configured max angle. Cosine
        // comparison avoids per-target acos() calls.
        double minCos = Math.cos(Math.toRadians(maxAngleDeg));

        class_243 look = client.field_1724.method_5720();

        class_238 searchBox = class_238.method_30048(eye, maxRange * 2, maxRange * 2, maxRange * 2);
        List<class_1657> nearby = client.field_1687.method_8390(
                class_1657.class, searchBox,
                p -> p != client.field_1724 && p.method_5805() && !p.method_7325());

        class_1657 bestTarget = null;
        class_243        bestAimPoint = null;
        double       bestScore = -1.0;   // higher cos = closer to crosshair

        for (class_1657 p : nearby) {
            class_243 aimPoint = p.method_33571();             // aim at the head
            class_243 toTarget = aimPoint.method_1020(eye);
            double dist = toTarget.method_1033();
            if (dist < 0.01 || dist > maxRange) continue;

            double cos = look.method_1026(toTarget.method_1021(1.0 / dist));
            if (cos < minCos) continue;                 // outside the cone

            // Pick the target most aligned with the crosshair (tie-break by
            // proximity by adding a small distance penalty).
            double score = cos - dist * 0.001;
            if (score > bestScore) {
                bestScore    = score;
                bestTarget   = p;
                bestAimPoint = aimPoint;
            }
        }

        if (bestTarget == null) return;

        class_243 delta = bestAimPoint.method_1020(eye);
        double targetYaw   = Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350));
        double horiz       = Math.sqrt(delta.field_1352 * delta.field_1352 + delta.field_1350 * delta.field_1350);
        double targetPitch = -Math.toDegrees(Math.atan2(delta.field_1351, horiz));

        float curYaw   = client.field_1724.method_36454();
        float curPitch = client.field_1724.method_36455();

        double yawDelta   = class_3532.method_15338(targetYaw - curYaw);
        double pitchDelta = targetPitch - curPitch;

        client.field_1724.method_36456  ((float) (curYaw   + yawDelta   * strength));
        client.field_1724.method_36457((float) (curPitch + pitchDelta * strength));
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private class_1309 getLookedAtLiving(class_310 client) {
        if (client.field_1765 == null) return null;
        if (client.field_1765.method_17783() != class_239.class_240.field_1331) return null;

        class_1297 entity = ((class_3966) client.field_1765).method_17782();
        if (entity instanceof class_1309 living && living != client.field_1724) {
            return living;
        }
        return null;
    }

    private class_1657 getLookedAtPlayer(class_310 client) {
        if (client.field_1765 == null) return null;
        if (client.field_1765.method_17783() != class_239.class_240.field_1331) return null;

        class_1297 entity = ((class_3966) client.field_1765).method_17782();
        if (entity instanceof class_1657 target && target != client.field_1724) {
            return target;
        }
        return null;
    }

    private int findAxeSlot(class_310 client) {
        int current = client.field_1724.method_31548().method_67532();
        if (client.field_1724.method_31548().method_5438(current).method_7909() instanceof class_1743) {
            return current;
        }
        for (int i = 0; i < 9; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1743) return i;
        }
        return -1;
    }

    private int findBreachMaceSlot(class_310 client) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() instanceof class_9362 && hasBreach(client, stack)) return i;
        }
        return -1;
    }

    private int findBestMaceSlot(class_310 client) {
        int densitySlot   = -1;
        int breachSlot    = -1;
        int plainMaceSlot = -1;

        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (!(stack.method_7909() instanceof class_9362)) continue;

            if (densitySlot == -1 && hasDensity(client, stack)) {
                densitySlot = i;
            } else if (breachSlot == -1 && hasBreach(client, stack)) {
                breachSlot = i;
            } else if (plainMaceSlot == -1) {
                plainMaceSlot = i;
            }
        }

        if (densitySlot   != -1) return densitySlot;
        if (breachSlot    != -1) return breachSlot;
        return plainMaceSlot;
    }

    private boolean hasDensity(class_310 client, class_1799 stack) {
        return hasEnchantment(client, stack, class_1893.field_50157);
    }

    private boolean hasBreach(class_310 client, class_1799 stack) {
        return hasEnchantment(client, stack, class_1893.field_50158);
    }

    private boolean hasEnchantment(class_310 client,
                                    class_1799 stack,
                                    net.minecraft.class_5321<class_1887> key) {
        var registry = client.field_1687.method_30349().method_30530(class_7924.field_41265);
        class_6880<class_1887> entry = registry.method_46746(key).orElse(null);
        if (entry == null) return false;
        return class_1890.method_8225(entry, stack) > 0;
    }
}
