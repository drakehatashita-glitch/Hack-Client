package com.shieldmacemod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public class ShieldMaceMod implements ClientModInitializer {

    public static class_304 openGuiKey;
    public static class_304 toggleComboKey;
    public static class_304 toggleBreachSwapKey;
    public static class_304 toggleMaceSpamKey;
    public static class_304 togglePearlInterceptKey;
    public static class_304 toggleSilentAimKey;
    public static class_304 toggleHeightSmashKey;
    public static class_304 toggleHitboxExpandKey;
    public static class_304 toggleAutoTotemKey;
    public static class_304 toggleNoFallKey;
    public static class_304 toggleKillAuraKey;
    public static class_304 toggleFlightKey;
    public static class_304 toggleBlinkKey;

    public static ShieldMaceFeature feature;
    public static PearlInterceptor   pearlInterceptor;

    // GLFW key codes (inlined to avoid LWJGL compile-time dependency)
    private static final int GLFW_KEY_UNKNOWN       = -1;
    private static final int GLFW_KEY_RIGHT_SHIFT   = 344;
    private static final int GLFW_KEY_RIGHT_CONTROL = 345;
    private static final int GLFW_KEY_RIGHT_ALT     = 346;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.openGui",
                class_3675.class_307.field_1668,
                GLFW_KEY_RIGHT_SHIFT,
                class_304.class_11900.field_62556));

        toggleComboKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleCombo",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        toggleBreachSwapKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleBreachSwap",
                class_3675.class_307.field_1668,
                GLFW_KEY_RIGHT_CONTROL,
                class_304.class_11900.field_62556));

        toggleMaceSpamKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleMaceSpam",
                class_3675.class_307.field_1668,
                GLFW_KEY_RIGHT_ALT,
                class_304.class_11900.field_62556));

        togglePearlInterceptKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.togglePearlIntercept",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        toggleSilentAimKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleSilentAim",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        toggleHeightSmashKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleHeightSmash",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        toggleHitboxExpandKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleHitboxExpand",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        toggleAutoTotemKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleAutoTotem",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        toggleNoFallKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleNoFall",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        toggleKillAuraKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleKillAura",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        toggleFlightKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleFlight",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        toggleBlinkKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.shieldmacemod.toggleBlink",
                class_3675.class_307.field_1668,
                GLFW_KEY_UNKNOWN,
                class_304.class_11900.field_62556));

        feature          = new ShieldMaceFeature();
        pearlInterceptor = new PearlInterceptor();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.method_1436()) {
                client.method_1507(new ShieldMaceGui());
            }
            while (toggleComboKey.method_1436()) {
                feature.toggleCombo(client);
            }
            while (toggleBreachSwapKey.method_1436()) {
                feature.toggleBreachSwap(client);
            }
            while (toggleMaceSpamKey.method_1436()) {
                feature.toggleMaceSpam(client);
            }
            while (togglePearlInterceptKey.method_1436()) {
                pearlInterceptor.toggle(client);
            }
            while (toggleSilentAimKey.method_1436()) {
                feature.toggleSilentAim(client);
            }
            while (toggleHeightSmashKey.method_1436()) {
                feature.toggleHeightSmash(client);
            }
            while (toggleHitboxExpandKey.method_1436()) {
                feature.toggleHitboxExpand(client);
            }
            while (toggleAutoTotemKey.method_1436()) {
                feature.toggleAutoTotem(client);
            }
            while (toggleNoFallKey.method_1436()) {
                feature.toggleNoFall(client);
            }
            while (toggleKillAuraKey.method_1436()) {
                feature.toggleKillAura(client);
            }
            while (toggleFlightKey.method_1436()) {
                feature.toggleFlight(client);
            }
            while (toggleBlinkKey.method_1436()) {
                feature.toggleBlink(client);
            }
            feature.tick(client);
            pearlInterceptor.tick(client);
        });
    }
}
