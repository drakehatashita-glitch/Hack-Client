# Shield Mace Mod — Install Instructions

**For Minecraft 1.21.11 with Fabric Loader ≥ 0.15 + Fabric API**

1. Drop `shield-mace-mod-1.0.0+1.21.11.jar` into your `.minecraft/mods/` folder.
2. Launch the game.
3. Go to Options -> Controls -> Key Binds.  Search "Shield Mace" and rebind from default Right Shift if desired.
4. In-game, press the bound key to toggle the combo on/off (action-bar message confirms state).

## What it does
When ENABLED and your crosshair is on another player:
 1. Equips an axe from your hotbar and swings (disables their shield).
 2. After ~150 ms equips the best mace in your hotbar:
    - Prefers a Density-enchanted mace.
    - Falls back to a Breach-enchanted mace.
    - Falls back to any plain mace.
 3. Swings the mace at the target.

## Requirements
- Fabric Loader >= 0.15.0
- Fabric API (any for 1.21.11)
- Java 21
