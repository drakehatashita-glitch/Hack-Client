# Shield Mace Mod 1.1.0 — Install Instructions

**For Minecraft 1.21.11 with Fabric Loader >= 0.15 + Fabric API**

1. Drop `shield-mace-mod-1.1.0+1.21.11.jar` into your `.minecraft/mods/` folder.
2. Launch the game.
3. Go to Options -> Controls -> Key Binds.  Search "Shield Mace" to rebind the toggle key (default: Right Shift).
4. Press the toggle key in-game to turn the mod on/off (action-bar message confirms).

## Features

### Auto Shield-Break + Mace Combo (always running when ON)
When your crosshair is on a player:
 1. Equips an axe from your hotbar and swings (disables their shield).
 2. After ~150 ms equips the best mace in your hotbar:
    - Prefers a Density-enchanted mace.
    - Falls back to a Breach-enchanted mace.
    - Falls back to any plain mace.
 3. Swings the mace at the target.

### Click-to-Break Shield (new in 1.1.0)
When you LEFT-CLICK while looking at a player who is actively blocking:
 1. Swaps to your axe and swings (breaks their shield).
 2. After ~150 ms automatically swaps back to whatever you had equipped.
This is priority over the auto-combo, so blocking targets get the axe swap first.

## Requirements
- Fabric Loader >= 0.15.0
- Fabric API (any build for 1.21.11)
- Java 21
